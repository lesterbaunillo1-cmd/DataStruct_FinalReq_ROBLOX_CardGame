local Deal = require(script.Parent.DealCards)

task.wait(5) -- give players time to load in

local hands = Deal()

-- later: send to players, show UI etc.
